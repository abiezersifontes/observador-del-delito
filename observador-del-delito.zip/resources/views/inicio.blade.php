@extends('layout.menu')
@section('sidebar')
  <div class="container">
    <div class="row">
      <div class="col-lg-12 col-md-12 ">
        </br></br>
        
          <h3><strong>CESYC </strong>"CENTRO DE ESTUDIOS SOCIALES Y CULTURALES"</h3>
          <h4>Observador Digital del Delito</h4>
        </br></br>
      </div>
    </div>
  </div>
@endsection
